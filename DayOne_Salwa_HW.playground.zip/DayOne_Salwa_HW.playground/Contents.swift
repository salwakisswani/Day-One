import UIKit


let numbers = [1, 2, 3, 4, 5]
//var evenNumbers = [Int]()
//for number in numbers {
//  if(number % 2 ==0) {
//      evenNumbers.append(number)
//  }
//}


func isEven(x:Int) -> Bool {
    return x % 2 == 0
    
}

let evenNumbers = numbers.filter(isEven)

func isOdd(x:Int) -> Bool {
    return !isEven(x: x)
}

let oddNumbers = numbers.filter(isOdd)

print(evenNumbers.sorted )

func numbers(x:Int) -> Bool  {
    return !myArray (x: Int)
}
let myArray = [1, 2, 3, 4, 5]


print(myArray.sorted { (int1, int2) ->
    Bool in
    return int1 % 2 == 0
})


print(myArray.filter({ (theInt) -> Bool in
    return theInt % 2 != 0

}

